/*
SPDX-License-Identifier: GPL-3.0-or-later
Copyright (c) 2025 RussDev7, unknowghost0
This file is part of https://github.com/RussDev7/CMZDedicatedServers - see LICENSE for details.
*/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;

namespace CMZDedicatedSteamServer.Plugins
{
    /// <summary>
    /// Dynamically loads plugin assemblies from the Plugins directory.
    /// </summary>
    internal sealed class PluginLoader
    {
        #region Fields

        private readonly string _pluginsDir;
        private readonly Action<string> _log;
        private readonly PluginConfig _config;

        #endregion

        #region Constructor

        public PluginLoader(string baseDir, Action<string> log)
        {
            _pluginsDir = Path.Combine(baseDir ?? AppDomain.CurrentDomain.BaseDirectory, "Plugins");
            _log = log ?? (_ => { });
            Directory.CreateDirectory(_pluginsDir);

            string configPath = Path.Combine(_pluginsDir, "plugins.ini");
            _config = PluginConfig.Load(configPath);
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Loads all enabled plugin DLLs from the Plugins directory.
        /// </summary>
        /// <returns>List of loaded plugin instances.</returns>
        public List<IServerWorldPlugin> LoadPlugins()
        {
            var loadedPlugins = new List<IServerWorldPlugin>();
            var failedPlugins = new List<string>();
            var loadedDependencies = new List<string>();
            var failedDependencies = new List<string>();

            if (!Directory.Exists(_pluginsDir))
            {
                _log($"[PluginLoader] Plugins directory does not exist: {_pluginsDir}");
                return loadedPlugins;
            }

            _log($"[PluginLoader] Scanning for plugins in: {_pluginsDir}");

            // Check Dependencies folder
            string dependenciesDir = Path.Combine(_pluginsDir, "Dependencies");
            if (Directory.Exists(dependenciesDir))
            {
                string[] depDllFiles = Directory.GetFiles(dependenciesDir, "*.dll");
                _log($"[PluginLoader] Found {depDllFiles.Length} DLL files in Dependencies folder.");
                foreach (string depDll in depDllFiles)
                {
                    string depName = Path.GetFileName(depDll);
                    _log($"[PluginLoader]   - {depName}");
                    loadedDependencies.Add(depName);
                }
                _log($"[PluginLoader] Successfully loaded {loadedDependencies.Count} dependencies from Dependencies folder.");
                if (failedDependencies.Count > 0)
                {
                    _log($"[PluginLoader] Unsuccessfully loaded {failedDependencies.Count} dependencies: {string.Join(", ", failedDependencies)}");
                }
            }
            else
            {
                _log($"[PluginLoader] Dependencies folder does not exist.");
            }

            string[] dllFiles = Directory.GetFiles(_pluginsDir, "*.dll");
            _log($"[PluginLoader] Found {dllFiles.Length} DLL files in Plugins directory.");

            foreach (string dllPath in dllFiles)
            {
                string fileName = Path.GetFileNameWithoutExtension(dllPath);

                // Skip built-in plugin directories
                if (IsBuiltInPlugin(fileName))
                {
                    _log($"[PluginLoader] Skipping built-in plugin: {fileName}");
                    continue;
                }

                // Add plugin to config file if not already there
                _config.AddPlugin(fileName);

                // Check if plugin is enabled in config
                if (!_config.IsPluginEnabled(fileName))
                {
                    _log($"[PluginLoader] Plugin disabled in config: {fileName}");
                    continue;
                }

                try
                {
                    Assembly assembly = Assembly.LoadFrom(dllPath);
                    _log($"[PluginLoader] Loaded assembly: {assembly.GetName().Name}");

                    var pluginTypes = assembly.GetTypes()
                        .Where(t => typeof(IServerWorldPlugin).IsAssignableFrom(t) && !t.IsInterface && !t.IsAbstract)
                        .ToList();

                    if (pluginTypes.Count == 0)
                    {
                        _log($"[PluginLoader] Warning: No plugin types found in {fileName}");
                    }

                    foreach (Type pluginType in pluginTypes)
                    {
                        try
                        {
                            IServerWorldPlugin plugin = (IServerWorldPlugin)Activator.CreateInstance(pluginType);
                            loadedPlugins.Add(plugin);
                            _log($"[PluginLoader] Loaded plugin instance: {plugin.Name} (from {fileName})");
                        }
                        catch (Exception ex)
                        {
                            _log($"[PluginLoader] Failed to create instance of {pluginType.Name}: {ex.Message}");
                        }
                    }
                }
                catch (BadImageFormatException)
                {
                    _log($"[PluginLoader] Failed to load assembly {fileName}: Not a valid .NET assembly or wrong architecture (32/64-bit mismatch)");
                    failedPlugins.Add(fileName);
                }
                catch (FileNotFoundException ex)
                {
                    _log($"[PluginLoader] Failed to load assembly {fileName}: Missing dependencies - {ex.Message}");
                    failedPlugins.Add(fileName);
                }
                catch (FileLoadException ex)
                {
                    _log($"[PluginLoader] Failed to load assembly {fileName}: Could not load file or assembly - {ex.Message}");
                    failedPlugins.Add(fileName);
                }
                catch (Exception ex)
                {
                    _log($"[PluginLoader] Failed to load assembly {fileName}: {ex.GetType().Name} - {ex.Message}");
                    failedPlugins.Add(fileName);
                }
            }

            _log($"[PluginLoader] Successfully loaded {loadedPlugins.Count} external plugins.");
            if (failedPlugins.Count > 0)
            {
                _log($"[PluginLoader] Unsuccessfully loaded {failedPlugins.Count} plugins: {string.Join(", ", failedPlugins)}");
            }
            
            return loadedPlugins;
        }

        #endregion

        #region Private Methods

        private bool IsBuiltInPlugin(string fileName)
        {
            return fileName.Equals("Announcements", StringComparison.OrdinalIgnoreCase) ||
                   fileName.Equals("FloodGuard", StringComparison.OrdinalIgnoreCase) ||
                   fileName.Equals("RegionProtect", StringComparison.OrdinalIgnoreCase) ||
                   fileName.Equals("RememberTime", StringComparison.OrdinalIgnoreCase) ||
                   fileName.Equals("VanillaSpawners", StringComparison.OrdinalIgnoreCase);
        }

        #endregion

        #region Config Class

        private sealed class PluginConfig
        {
            private readonly Dictionary<string, bool> _pluginStates = new(StringComparer.OrdinalIgnoreCase);
            private readonly string _configPath;

            public bool IsPluginEnabled(string pluginName)
            {
                // Default to enabled if not specified
                return !_pluginStates.TryGetValue(pluginName, out bool enabled) || enabled;
            }

            public PluginConfig(string configPath)
            {
                _configPath = configPath;
            }

            public static PluginConfig Load(string configPath)
            {
                var config = new PluginConfig(configPath);

                if (!File.Exists(configPath))
                {
                    // Create default config
                    string defaultContent =
@"# Plugin Configuration
# Set enabled=false to disable a specific plugin
# Format: PluginName = true/false

[Plugins]
# Example: MyCustomPlugin = true
";
                    File.WriteAllText(configPath, defaultContent);
                    return config;
                }

                string section = string.Empty;
                foreach (string line in File.ReadAllLines(configPath))
                {
                    string trimmed = line.Trim();

                    if (string.IsNullOrEmpty(trimmed) || trimmed.StartsWith("#") || trimmed.StartsWith(";"))
                        continue;

                    if (trimmed.StartsWith("[") && trimmed.EndsWith("]"))
                    {
                        section = trimmed.Substring(1, trimmed.Length - 2).Trim();
                        continue;
                    }

                    int equalsIndex = trimmed.IndexOf('=');
                    if (equalsIndex > 0)
                    {
                        string key = trimmed.Substring(0, equalsIndex).Trim();
                        string value = trimmed.Substring(equalsIndex + 1).Trim();

                        if (section.Equals("Plugins", StringComparison.OrdinalIgnoreCase))
                        {
                            if (bool.TryParse(value, out bool enabled))
                            {
                                config._pluginStates[key] = enabled;
                            }
                        }
                    }
                }

                return config;
            }

            public void AddPlugin(string pluginName)
            {
                if (!_pluginStates.ContainsKey(pluginName))
                {
                    _pluginStates[pluginName] = true; // Default to enabled
                    Save();
                }
            }

            private void Save()
            {
                try
                {
                    var lines = File.ReadAllLines(_configPath).ToList();
                    int insertIndex = -1;

                    for (int i = 0; i < lines.Count; i++)
                    {
                        string trimmed = lines[i].Trim();
                        if (trimmed.StartsWith("[Plugins]", StringComparison.OrdinalIgnoreCase))
                        {
                            insertIndex = i + 1;
                        }
                        else if (trimmed.StartsWith("[") && trimmed.EndsWith("]") && insertIndex != -1)
                        {
                            break;
                        }
                    }

                    if (insertIndex == -1)
                    {
                        // No [Plugins] section, add one
                        lines.Add("");
                        lines.Add("[Plugins]");
                        insertIndex = lines.Count;
                    }

                    // Add new plugins that aren't in the file
                    foreach (var kvp in _pluginStates)
                    {
                        bool found = false;
                        foreach (var line in lines)
                        {
                            string trimmed = line.Trim();
                            if (trimmed.StartsWith(kvp.Key, StringComparison.OrdinalIgnoreCase) && trimmed.Contains("="))
                            {
                                found = true;
                                break;
                            }
                        }

                        if (!found)
                        {
                            lines.Insert(insertIndex, $"{kvp.Key} = {kvp.Value.ToString().ToLower()}");
                            insertIndex++;
                        }
                    }

                    File.WriteAllLines(_configPath, lines);
                }
                catch
                {
                    // Silently fail on save errors
                }
            }
        }

        #endregion
    }
}
