/*
SPDX-License-Identifier: GPL-3.0-or-later
Copyright (c) 2025 [Your Name]
This file is part of [Your Plugin Name] - see LICENSE for details.
*/

using System;
using CMZDedicatedSteamServer.Plugins;

namespace ExamplePlugin
{
    /// <summary>
    /// Example plugin demonstrating how to create external DLL plugins for CMZDedicatedSteamServer.
    /// </summary>
    /// <remarks>
    /// To use this plugin:
    /// 1. Build this as a class library targeting .NET Framework 4.7.2 or compatible
    /// 2. Reference the CMZDedicatedSteamServer project or copy the plugin interfaces
    /// 3. Copy the compiled DLL to the server's Plugins folder
    /// 4. Enable it in plugins.ini if needed
    /// 5. Restart the server
    /// </remarks>
    public class ExamplePlugin : IServerWorldPlugin, IServerPlayerEventPlugin
    {
        #region Fields

        private Action<string> _log = _ => { };
        private string _pluginDir;

        #endregion

        #region Properties

        public string Name => "ExamplePlugin";

        #endregion

        #region Plugin Lifecycle

        public void Initialize(ServerPluginContext context)
        {
            _log = context?.Log ?? (_ => { });

            string serverDir = context?.BaseDir ?? AppDomain.CurrentDomain.BaseDirectory;
            _pluginDir = System.IO.Path.Combine(serverDir, "Plugins", "ExamplePlugin");
            System.IO.Directory.CreateDirectory(_pluginDir);

            _log($"[ExamplePlugin] Initialized. Plugin directory: {_pluginDir}");
        }

        public bool BeforeHostMessage(HostMessageContext context)
        {
            // Return true to consume/block the packet
            // Return false to allow normal server handling
            return false;
        }

        #endregion

        #region Player Events

        public void OnPlayerJoined(ServerPlayerEventContext context)
        {
            _log($"[ExamplePlugin] Player joined: {context.PlayerName} (ID: {context.PlayerId})");
            
            // Send a welcome message to the player
            context.SendPrivateMessage?.Invoke($"Welcome {context.PlayerName}! This is from ExamplePlugin.");
        }

        public void OnPlayerLeft(ServerPlayerEventContext context)
        {
            _log($"[ExamplePlugin] Player left: {context.PlayerName} (ID: {context.PlayerId})");
        }

        #endregion
    }
}
